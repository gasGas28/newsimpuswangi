<template>
    ini bayi
</template>
<script setup>
</script>