<template>
    <div class="row card-body">
        <div class="col-6">
            <div class="mb-3">
                <label for="tanggal-anamnesa" class="form-label fw-bold">Perkusi</label>
                <select type="text" id="tanggal-anamnesa" class="form-control">
                    <option value="">+</option>
                    <option value="">-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="tanggal-anamnesa" class="form-label fw-bold">Druk</label>
                <select type="text" id="tanggal-anamnesa" class="form-control">
                    <option value="">+</option>
                    <option value="">-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="tanggal-anamnesa" class="form-label fw-bold">Palpasi</label>
                <select type="text" id="tanggal-anamnesa" class="form-control">
                    <option value="">+</option>
                    <option value="">-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="tanggal-anamnesa" class="form-label fw-bold">Luxasi</label>
                <select type="text" id="tanggal-anamnesa" class="form-control">
                    <option value="">+</option>
                    <option value="">-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="tanggal-anamnesa" class="form-label fw-bold">Vitalitas</label>
                <select type="text" id="tanggal-anamnesa" class="form-control">
                    <option value="">+</option>
                    <option value="">-</option>
                </select>
            </div>

        </div>

    </div>
</template>