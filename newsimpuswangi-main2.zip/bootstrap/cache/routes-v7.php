<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LPqObR3qte5b9trp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_csrf-debug' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BuTE2gzqFiiez0Kp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'login.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/loket' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'loket.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang-layanan/poli' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.poli.alt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laborat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laborat.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/farmasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vYtqZn61HHkZ8yDK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/farmasi/master' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nAicnJXihBi8AbME',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/farmasi/resep-langsung' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6vBqIBNd9xI62n5w',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/farmasi/pelayanan-resep' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R010DzClvBBHFXIv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/farmasi/laporan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FPPabDRAFbdMuhEp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filter',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pasien' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'loket.pasien',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pasien/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'loket.search',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/templete/button' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'templete.button',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/templete/form' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'templete.form',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/templete/table' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'templete.table',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/templete/card' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'templete.card',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/templete/pagination' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'templete.pagination',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home.home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/loket' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.loket',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/loket/tampilkan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.loket.tampilkan-laporan-loket',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/rujukan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.rujukan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/umum' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.umum',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/gigi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.gigi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/kia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.kia',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/lab' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.lab',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/laporan/kb' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.kb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/ugd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.ugd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/rawat-inap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.rawat-inap',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/kunjungan-sehat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.kunjungan-sehat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/sanitasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.sanitasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/sanitasi/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.sanitasi.register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/sanitasi/sanitasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.sanitasi.laporan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/laporan/sanitasi/kasus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'laporan.sanitasi.kasus',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesling' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesling.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesling/konseling-sanitasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesling.konseling',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesling/pengukuran-kebugaran-haji' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesling.haji',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesling/pengukuran-kebugaran-anak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesling.anak',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konselingcatin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konselingcatin',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konselinghaji' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konselinghaji',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konselingimunisasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konselingimunisasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konselinganak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konselinganak',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konselingibu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konselingibu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konselingkb' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konselingkb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konsultasigizi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konsultasigizi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/kesga/konsultasilansia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesga.konsultasilansia',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/ptm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.ptm.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/ptm/konselingberhentimerokok' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.ptm.konselingberhentimerokok',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/ptm/skriningfaktorrisiko' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.ptm.skriningfaktorrisiko',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/p3m' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.p3m.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/p3m/konselinghivaids' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.p3m.konselinghivaids',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/p3m/konselinglroa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.p3m.konselinglroa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/p3m/konselingtb' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.p3m.konselingtb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/yankes-primer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.yankes-primer.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/yankes-primer/kunjungankonsultasitradisional' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.yankes-primer.kunjungankonsultasitradisional',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/yankes-primer/kunjunganketerangansehat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.yankes-primer.kunjunganketerangansehat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/farmasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.farmasi.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/farmasi/permintaanobat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.farmasi.permintaanobat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/biakes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.biakes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/biakes/pembiayaanjaminansehat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.biakes.pembiayaanjaminansehat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/promkes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.promkes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/promkes/kesehatanpeduliremaja' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.promkes.kesehatanpeduliremaja',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/promkes/diagnosa/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.promkes.diagnosa.list',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/promkes/tindakan/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.promkes.tindakan.list',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/home-visit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.home-visit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/sehat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.sehat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/sehat/pelayanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.sehat.pelayanan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/mal-sehat/rapid-test' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.rapid-test',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang_layanan/simpus/kunjungan-online/pelayanan/anamnesa/objective' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.setAnamnesaObjective',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang_layanan/simpus/poli' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.poli',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang_layanan/master-tindakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.master-tindakan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang_layanan/simpus/umum/pelayanan/mulaiPelayanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-umum.mulai-pemeriksaan-pasien',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang_layanan/api/diagnosa-medis' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.diagnosa-medis',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang_layanan/master-obat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.master-obat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/set-waktu-sample' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.setWaktuSample',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/update-nilai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.updateNilaiLab',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/paginasi-master-pemeriksaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.paginasiMasterPemeriksaan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/permohonan/simpan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.simpanPermohonan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/param/headers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.param.headers',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/tindakan/hapus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.hapusTindakan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/param/browse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.param.browse',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/laborat/param/simpan-terpilih' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.param.simpanTerpilih',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/kia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.kia',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/kia/anc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.anc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/kia/anc/pelayanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-anc.kunjunganANC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/kia/anc/pelayanan/obstetri' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-anc.obstetri',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/kia/anc/pelayanan/DataDiagnosa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-anc.dataDiagnosa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/kia/anc/pelayanan/diagnosaKep' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-anc.diagnosaKep',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kia/cari-diagnosa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.cari-diagnosa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/simpus/kia/kematian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.kematian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang_layanan/laborat/param/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.param.categories',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ruang-layanan/laborat/hapus-semua' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.hapusSemuaTindakan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/owner' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'owner.panel',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/owner/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::929SgLF6K1sSbA1l',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/owner/puskesmas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xEUl3DGQzzlEx2tU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/owner/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TkXbcLAg9C9weeGX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0Tu3kCll1hTjSkX6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/owner/online-users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dWEsmJNoMt3zRdjl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/auth/password/force-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'auth.password.force-update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/owner/loket-delete-logs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'owner.loket-delete-logs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/owner/logs/loket-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'owner.logs.loket',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cek-db' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xwVWtC83jot7xld8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/pasien/([^/]++)(?|/edit(*:31)|(*:38))|/mal\\-sehat/(?|kesling/detail/([^/]++)(*:84)|biakes/pembiayaanjaminansehat/pelayanan/([^/]++)(*:139)|promkes/kesehatanpeduliremaja/pelayanan/([^/]++)(*:195))|/ruang_layanan/simpus(?|/(?|kunjungan\\-online(?|(?:/([^/]++)(?:/([^/]++))?)?(*:280)|/(?|pelayanan/(?|([^/]++)/([^/]++)/([^/]++)(*:331)|anamnesa(*:347)|mulaiPelayanan(*:369)|diagnosa\\-medis(*:392))|surat\\-rujukan/([^/]++)(*:424)|([^/]++)/(?|surat\\-rujukan(?|/create(*:468)|(*:476))|riwayat\\-kesehatan(*:503)|cppt(*:515))))|poli/([^/]++)(*:539))|(?:/([^/]++)(?:/([^/]++))?)?(*:576)|/(?|p(?|elayanan(?|/(?|([^/]++)/([^/]++)/([^/]++)(*:633)|s(?|et\\-anamnesa\\-subjective/([^/]++)(*:678)|impan\\-(?|gizi/([^/]++)(*:709)|sanitasi/([^/]++)(*:734)|rujuk/([^/]++)/([^/]++)(*:765)))|tindakan/([^/]++)/([^/]++)/([^/]++)(*:810)|d(?|iagnosa\\-(?|medis/([^/]++)(?|/([^/]++)(*:860)|(*:868))|keperawatan([^/]++)(*:896))|etail\\-resep\\-obat/([^/]++)/([^/]++)(*:941))|resep\\-obat/([^/]++)/([^/]++)(*:979)|hapus\\-rujuk/([^/]++)(*:1008)|batal\\-berobat\\-jalan/([^/]++)/([^/]++)(*:1056))|Detail/(?|s(?|urat\\-(?|rujuk(?|/([^/]++)/([^/]++)(*:1115)|\\-form/([^/]++)/([^/]++)(*:1148)|an\\-form\\-edit/([^/]++)/([^/]++)/([^/]++)(*:1198))|keterangan\\-list/([^/]++)/([^/]++)(*:1242))|impan\\-(?|rujukan/([^/]++)(*:1278)|surat\\-keterangan/([^/]++)(*:1313)))|c(?|etak\\-(?|rujukan/([^/]++)(*:1353)|surat\\-keterangan/([^/]++)(*:1388))|reate\\-surat\\-keterangan/([^/]++)/([^/]++)(*:1440))|update\\-surat\\-rujukan/([^/]++)/([^/]++)(*:1490)|hapus\\-surat\\-(?|rujukan/([^/]++)(*:1532)|keterangan/([^/]++)(*:1560))|edit\\-surat\\-keterangan//([^/]++)/([^/]++)/([^/]++)(*:1621)))|op\\-up/get\\-ukk/([^/]++)(*:1656))|u(?|mum/(?|form\\-surat\\-keterangan(*:1700)|pelayanan/set\\-anamnesa\\-objective/([^/]++)(*:1752)|laborat/simpan\\-permohonan\\-lab/([^/]++)(*:1801))|pdate\\-surat\\-keterangan(*:1835))|diagnosa/diagnosa\\-keperawatan\\-simpan/([^/]++)/([^/]++)(*:1901)|hapus\\-(?|resep\\-obat/([^/]++)(*:1940)|detail\\-resep\\-obat/([^/]++)(*:1977))|g(?|et\\-pelayanan/([^/]++)/([^/]++)(*:2022)|i(?|gi(?|(*:2040)|/pelayanan/(?|([^/]++)(*:2071)|anamnesa\\-(?|subjective(*:2103)|objective(*:2121))|diagnosa\\-medis(?|(*:2149)|/([^/]++)(*:2167))|planning\\-(?|tindakan(?|(*:2201)|/([^/]++)(*:2219))|pengobatan(?|(*:2242)|\\-detail(*:2259)))))|zi(?|(*:2277)|/pelayanan(*:2296))))|laborat/(?|([^/]++)/([^/]++)/([^/]++)(*:2345)|list\\-permohonan/([^/]++)(*:2379))|r(?|iwayat\\-pasien/([^/]++)/([^/]++)(*:2425)|a(?|nap(*:2441)|wat\\-inap(?|(*:2462)|/pe(?|n(?|erimaan\\-pasien(*:2496)|geluaran(*:2513))|rawatan(*:2530)))))|s(?|impan\\-ukk/([^/]++)(*:2566)|anitasi(?|(*:2585)|/pelayanan(*:2604)))|cppt/([^/]++)/([^/]++)(*:2637)))|/s(?|impus/(?|laborat/(?|p(?|emeriksaan/(?|([^/]++)(*:2699)|simpan(*:2714)|paket/([^/]++)(*:2737))|aram/(?|([0-9]+)/subheaders(*:2774)|([0-9]+)/simpan(*:2798)))|detail/([^/]++)(*:2824))|kia/(?|anc/pelayanan/(?|([^/]++)/([^/]++)/([^/]++)(*:2884)|DataDiagnosa/([^/]++)(*:2914))|pelayanan/([^/]++)/([^/]++)/([^/]++)(*:2960)|kematian/pelayanan/([^/]++)/([^/]++)/([^/]++)(*:3014)))|torage/(.*)(*:3036))|/api/owner/users/([^/]++)/(?|roles(*:3080)|force\\-logout(*:3102))|/users/([^/]++)(?|/password\\-changed(*:3148)|(*:3157)))/?$}sDu',
    ),
    3 => 
    array (
      31 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'loket.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      38 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pasien.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      84 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.kesling.detail',
          ),
          1 => 
          array (
            0 => 'noUrut',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      139 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.biakes.pembiayaanjaminansehat.pelayanan',
          ),
          1 => 
          array (
            0 => 'no_mr',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      195 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'mal-sehat.promkes.kesehatanpeduliremaja.pelayanan',
          ),
          1 => 
          array (
            0 => 'no_mr',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      280 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.index',
            'idPoli' => NULL,
            'klaster' => NULL,
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'klaster',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.pelayanan',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'idPoli',
            2 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      347 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.setAnamnesa',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      369 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.mulai-pemeriksaan-pasien',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.diagnosa-medis',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      424 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.surat-rujukan',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      468 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.surat-rujukan.create',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.surat-rujukan.store',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      503 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.riwayat-kesehatan',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      515 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kunj-online.cppt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      539 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.poli-kluster',
          ),
          1 => 
          array (
            0 => 'kluster',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      576 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.index',
            'idPoli' => NULL,
            'kluster' => NULL,
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'kluster',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.pelayanan',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'idPoli',
            2 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      678 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.setAnamnesaSubjective',
          ),
          1 => 
          array (
            0 => 'idLoket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      709 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpan-gizi',
          ),
          1 => 
          array (
            0 => 'idLoket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      734 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpan-sanitasi',
          ),
          1 => 
          array (
            0 => 'idPelayanan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      765 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpanRujukan',
          ),
          1 => 
          array (
            0 => 'idLoket',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      810 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpan-Tindakan',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idLoket',
            2 => 'idPelayanan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      860 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.set-diagnosa-medis',
          ),
          1 => 
          array (
            0 => 'idLoket',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.remove-diagnosa-medis',
          ),
          1 => 
          array (
            0 => 'idDiagnosa',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      896 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.remove-diagnosa-keperawatan',
          ),
          1 => 
          array (
            0 => 'idDiagnosa',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      941 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.set-detail-resep',
          ),
          1 => 
          array (
            0 => 'idResep',
            1 => 'idObat',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      979 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.set-resep-obat',
          ),
          1 => 
          array (
            0 => 'idLoket',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1008 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.hapusRujuk',
          ),
          1 => 
          array (
            0 => 'idpelayanan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1056 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.batal-berobat-jalan',
          ),
          1 => 
          array (
            0 => 'idLoket',
            1 => 'idpelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.surat-rujuk',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1148 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.surat-rujuk-form',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1198 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.surat-rujuk-form-edit',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPelayanan',
            2 => 'idSurat',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1242 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.surat-keterangan-list',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpan-rujukan',
          ),
          1 => 
          array (
            0 => 'idPoli',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1313 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpanSuket',
          ),
          1 => 
          array (
            0 => 'idPoli',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1353 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.cetak-rujukan',
          ),
          1 => 
          array (
            0 => 'idSurat',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1388 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.cetak-suket',
          ),
          1 => 
          array (
            0 => 'idSurat',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1440 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.create-surat-keterangan',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.update-rujukan',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idSurat',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1532 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.hapus-surat-rujukan',
          ),
          1 => 
          array (
            0 => 'idSurat',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1560 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.hapus-suket',
          ),
          1 => 
          array (
            0 => 'idSurat',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1621 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.edit-suket',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPelayanan',
            2 => 'idSurat',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1656 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.get-ukk',
          ),
          1 => 
          array (
            0 => 'idLoket',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1700 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-umum.form-surat-keterangan',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1752 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.setAnamnesaObjective',
          ),
          1 => 
          array (
            0 => 'idAnam',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1801 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpan-permohonan-lab',
          ),
          1 => 
          array (
            0 => 'idLoket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1835 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.update-suket',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1901 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.diagnosa-keperawatan',
          ),
          1 => 
          array (
            0 => 'idLoket',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1940 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.hapus-resep-obat',
          ),
          1 => 
          array (
            0 => 'idResepObat',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1977 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.hapus-detail-resep-obat',
          ),
          1 => 
          array (
            0 => 'idDetailResepObat',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2022 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.ambilPelayanan',
          ),
          1 => 
          array (
            0 => 'idLoket',
            1 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2040 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.gigi',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2071 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.pelayanan',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2103 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.setAnamnesaSubjective',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2121 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.setAnamnesaObjective',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2149 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.diagnosa-medis',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2167 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.remove-diagnosa-medis',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2201 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.set-PlanningTindakan',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2219 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.remove-data-tindakan',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2242 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.set-PlanningPengobatan',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2259 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-gigi.set-PlanningPengobatanDetail',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2277 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.gizi',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2296 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.gizi.pelayanan',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2345 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.form-laborat',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idLoket',
            2 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2379 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.getPermonanLab',
          ),
          1 => 
          array (
            0 => 'idLoket',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.riwayat-pasien',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPasien',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.ranap',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2462 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.rawat-inap',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2496 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.rawat-inap.penerimaan-pasien',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2513 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.rawat-inap.pengeluaran',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2530 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.rawat-inap.perawatan',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2566 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.simpan-ukk',
          ),
          1 => 
          array (
            0 => 'idLoket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2585 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.sanitasi',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2604 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.sanitasi.pelayanan',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.cppt',
          ),
          1 => 
          array (
            0 => 'idPoli',
            1 => 'idPasien',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2699 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.pemeriksaan',
          ),
          1 => 
          array (
            0 => 'loketId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2714 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.pemeriksaanSimpan',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2737 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.paketPemeriksaanSimpan',
          ),
          1 => 
          array (
            0 => 'paket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2774 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.param.subheaders',
          ),
          1 => 
          array (
            0 => 'header',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2798 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.param.simpan',
          ),
          1 => 
          array (
            0 => 'header',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2824 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan.laborat.detail',
          ),
          1 => 
          array (
            0 => 'idPermohonan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2884 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-anc.pelayanan',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'idPoli',
            2 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2914 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'diagnosa.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2960 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-kia.pelayanan',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'idPoli',
            2 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3014 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ruang-layanan-kematian.pelayanan',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'idPoli',
            2 => 'idPelayanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3036 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3080 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AwT5zG6wLB80VnNs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3102 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cyeFLlnkL92ikF14',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3148 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'owner.users.password_changed',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'owner.users.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LPqObR3qte5b9trp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:931:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'C:\\\\Users\\\\akusu\\\\OneDrive\\\\Documents\\\\6. Magang MKI DINKES\\\\BACKUP\\\\newsimpuswangi-main\\\\newsimpuswangi-main\\\\newsimpuswangi-main\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000007080000000000000000";}}',
        'as' => 'generated::LPqObR3qte5b9trp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BuTE2gzqFiiez0Kp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => '_csrf-debug',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:683:"function (\\Illuminate\\Http\\Request $r) {
    return \\response()->json([
        \'method\' => $r->method(),
        \'has_cookie_xsrf\' => $r->cookies->has(\'XSRF-TOKEN\'),
        \'has_cookie_sess\' => $r->cookies->has(\\config(\'session.cookie\')),
        \'token_input\' => $r->input(\'_token\') ? \'YES\' : \'NO\',
        \'token_header\' => $r->header(\'X-CSRF-TOKEN\') ? \'YES\' : \'NO\',
        \'token_x_xsrf\' => $r->header(\'X-XSRF-TOKEN\') ? \'YES\' : \'NO\',
        \'session_driver\' => \\config(\'session.driver\'),
        \'session_id\' => $r->session()->getId(),
        \'host\' => $r->getHost(),
        \'origin\' => $r->headers->get(\'Origin\'),
        \'referer\' => $r->headers->get(\'Referer\'),
    ]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000070c0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BuTE2gzqFiiez0Kp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:70:"function () {
    return \\Inertia\\Inertia::render(\'Templete/Index\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000070e0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:46:"fn() => \\Inertia\\Inertia::render(\'Auth/Login\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007100000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@store',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:45:"fn() => \\Inertia\\Inertia::render(\'Dashboard\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000071d0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'loket.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'loket',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:47:"fn() => \\Inertia\\Inertia::render(\'Loket/Index\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000073d0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/loket',
        'where' => 
        array (
        ),
        'as' => 'loket.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.poli.alt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang-layanan/poli',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\CheckRole:pelayanan,owner,admin',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:53:"fn() => \\Inertia\\Inertia::render(\'RuangLayanan/Poli\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007180000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.poli.alt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laborat.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laborat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\CheckRole:laborat,pelayanan',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:49:"fn() => \\Inertia\\Inertia::render(\'Laborat/Index\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000071a0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'laborat.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:49:"fn() => \\Inertia\\Inertia::render(\'Reports/Index\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000071f0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reports.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:219:"function (\\Illuminate\\Http\\Request $request) {
    \\Illuminate\\Support\\Facades\\Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();
    return \\redirect()->route(\'login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007150000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:47:"fn() => \\Inertia\\Inertia::render(\'Admin/Index\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007210000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
        'as' => 'admin.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vYtqZn61HHkZ8yDK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'farmasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:49:"fn() => \\Inertia\\Inertia::render(\'Farmasi/Index\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007230000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/farmasi',
        'where' => 
        array (
        ),
        'as' => 'generated::vYtqZn61HHkZ8yDK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nAicnJXihBi8AbME' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'farmasi/master',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:54:"fn() => \\Inertia\\Inertia::render(\'Farmasi/MasterObat\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007250000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/farmasi',
        'where' => 
        array (
        ),
        'as' => 'generated::nAicnJXihBi8AbME',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6vBqIBNd9xI62n5w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'farmasi/resep-langsung',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:57:"fn() => \\Inertia\\Inertia::render(\'Farmasi/ResepLangsung\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007270000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/farmasi',
        'where' => 
        array (
        ),
        'as' => 'generated::6vBqIBNd9xI62n5w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R010DzClvBBHFXIv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'farmasi/pelayanan-resep',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:58:"fn() => \\Inertia\\Inertia::render(\'Farmasi/PelayananResep\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007290000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/farmasi',
        'where' => 
        array (
        ),
        'as' => 'generated::R010DzClvBBHFXIv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FPPabDRAFbdMuhEp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'farmasi/laporan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:58:"fn() => \\Inertia\\Inertia::render(\'Farmasi/LaporanFarmasi\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000072b0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/farmasi',
        'where' => 
        array (
        ),
        'as' => 'generated::FPPabDRAFbdMuhEp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filter' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Filter\\FilterController@index',
        'controller' => 'App\\Http\\Controllers\\Filter\\FilterController@index',
        'namespace' => NULL,
        'prefix' => '/filter',
        'where' => 
        array (
        ),
        'as' => 'filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'loket.pasien' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pasien',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'controller' => 'App\\Http\\Controllers\\Pasien\\PasienController',
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:51:"fn() => \\Inertia\\Inertia::render(\'Loket/AddPasien\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000072e0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/pasien',
        'where' => 
        array (
        ),
        'as' => 'loket.pasien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'loket.search' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pasien/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Pasien\\PasienController@index',
        'controller' => 'App\\Http\\Controllers\\Pasien\\PasienController@index',
        'namespace' => NULL,
        'prefix' => '/pasien',
        'where' => 
        array (
        ),
        'as' => 'loket.search',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'loket.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pasien/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Pasien\\PasienController@edit',
        'controller' => 'App\\Http\\Controllers\\Pasien\\PasienController@edit',
        'namespace' => NULL,
        'prefix' => '/pasien',
        'where' => 
        array (
        ),
        'as' => 'loket.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pasien.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pasien/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Pasien\\PasienController@update',
        'controller' => 'App\\Http\\Controllers\\Pasien\\PasienController@update',
        'namespace' => NULL,
        'prefix' => '/pasien',
        'where' => 
        array (
        ),
        'as' => 'pasien.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'templete.button' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'templete/button',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:51:"fn() => \\Inertia\\Inertia::render(\'Templete/Button\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007330000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/templete',
        'where' => 
        array (
        ),
        'as' => 'templete.button',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'templete.form' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'templete/form',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:49:"fn() => \\Inertia\\Inertia::render(\'Templete/Form\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007350000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/templete',
        'where' => 
        array (
        ),
        'as' => 'templete.form',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'templete.table' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'templete/table',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:50:"fn() => \\Inertia\\Inertia::render(\'Templete/Table\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007370000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/templete',
        'where' => 
        array (
        ),
        'as' => 'templete.table',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'templete.card' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'templete/card',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:49:"fn() => \\Inertia\\Inertia::render(\'Templete/Card\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007390000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/templete',
        'where' => 
        array (
        ),
        'as' => 'templete.card',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'templete.pagination' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'templete/pagination',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:55:"fn() => \\Inertia\\Inertia::render(\'Templete/Pagination\')";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000073b0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '/templete',
        'where' => 
        array (
        ),
        'as' => 'templete.pagination',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home.home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Home\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\Home\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '/home',
        'where' => 
        array (
        ),
        'as' => 'home.home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.loket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/loket',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\LaporanLoketController@index',
        'controller' => 'App\\Http\\Controllers\\Laporan\\LaporanLoketController@index',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.loket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.loket.tampilkan-laporan-loket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/loket/tampilkan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\LaporanLoketController@tampil',
        'controller' => 'App\\Http\\Controllers\\Laporan\\LaporanLoketController@tampil',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.loket.tampilkan-laporan-loket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.rujukan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/rujukan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\Rujukan\\RujukanController@index',
        'controller' => 'App\\Http\\Controllers\\Laporan\\Rujukan\\RujukanController@index',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.rujukan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.umum' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/umum',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.umum',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Laporan/Umum/Umum',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.gigi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/gigi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.gigi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Laporan/Gigi/Gigi',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.kia' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/kia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.kia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Laporan/Kia/Kia',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.lab' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/lab',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.lab',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Laporan/Lab/Lab',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.kb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'laporan/laporan/kb',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\Kb\\KbController@index',
        'controller' => 'App\\Http\\Controllers\\Laporan\\Kb\\KbController@index',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.kb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.ugd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/ugd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\Ugd\\UgdController@index',
        'controller' => 'App\\Http\\Controllers\\Laporan\\Ugd\\UgdController@index',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.ugd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.rawat-inap' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/rawat-inap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.rawat-inap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Laporan/Rawat-inap/Rawat-inap',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.kunjungan-sehat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/kunjungan-sehat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.kunjungan-sehat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Laporan/KunjunganSehat/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.sanitasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/sanitasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@index',
        'controller' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@index',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.sanitasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.sanitasi.register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/sanitasi/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@registerSanitasi',
        'controller' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@registerSanitasi',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.sanitasi.register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.sanitasi.laporan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/sanitasi/sanitasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@laporanSanitasi',
        'controller' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@laporanSanitasi',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.sanitasi.laporan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'laporan.sanitasi.kasus' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'laporan/sanitasi/kasus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'role:owner,admin,loket',
        ),
        'uses' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@laporanKasus',
        'controller' => 'App\\Http\\Controllers\\Laporan\\Sanitasi\\SanitasiController@laporanKasus',
        'namespace' => NULL,
        'prefix' => '/laporan',
        'where' => 
        array (
        ),
        'as' => 'laporan.sanitasi.kasus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.index',
        'namespace' => NULL,
        'prefix' => '/mal-sehat',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesling.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesling',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesling.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesling',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesling/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesling.konseling' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesling/konseling-sanitasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesling.konseling',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesling',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesling/KonselingSanitasi',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesling.haji' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesling/pengukuran-kebugaran-haji',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesling.haji',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesling',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesling/PengukuranKebugaranHaji',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesling.anak' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesling/pengukuran-kebugaran-anak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesling.anak',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesling',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesling/PengukuranKebugaranAnak',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesling.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesling/detail/{noUrut}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesling.detail',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesling',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesling/DetailKonselingSanitasi',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konselingcatin' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konselingcatin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konselingcatin',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonselingCatin',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konselinghaji' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konselinghaji',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konselinghaji',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonselingHaji',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konselingimunisasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konselingimunisasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konselingimunisasi',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonselingImunisasi',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konselinganak' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konselinganak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konselinganak',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonselingAnak',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konselingibu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konselingibu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konselingibu',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonselingIbu',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konselingkb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konselingkb',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konselingkb',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonselingKB',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konsultasigizi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konsultasigizi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konsultasigizi',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonsultasiGizi',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.kesga.konsultasilansia' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/kesga/konsultasilansia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.kesga.konsultasilansia',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/kesga',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Kesga/KonsultasiLansia',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.ptm.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/ptm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.ptm.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/ptm',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/PTM/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.ptm.konselingberhentimerokok' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/ptm/konselingberhentimerokok',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.ptm.konselingberhentimerokok',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/ptm',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/PTM/KonselingBerhentiMerokok',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.ptm.skriningfaktorrisiko' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/ptm/skriningfaktorrisiko',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.ptm.skriningfaktorrisiko',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/ptm',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/PTM/SkriningFaktorRisiko',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.p3m.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/p3m',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.p3m.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/p3m',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/P3M/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.p3m.konselinghivaids' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/p3m/konselinghivaids',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.p3m.konselinghivaids',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/p3m',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/P3M/KonselingHivAids',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.p3m.konselinglroa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/p3m/konselinglroa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.p3m.konselinglroa',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/p3m',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/P3M/KonselingLROA',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.p3m.konselingtb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/p3m/konselingtb',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.p3m.konselingtb',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/p3m',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/P3M/KonselingPenyakitTB',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.yankes-primer.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/yankes-primer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.yankes-primer.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/yankes-primer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/YankesPrimer/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.yankes-primer.kunjungankonsultasitradisional' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/yankes-primer/kunjungankonsultasitradisional',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.yankes-primer.kunjungankonsultasitradisional',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/yankes-primer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/YankesPrimer/KunjunganKonsultasiTradisional',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.yankes-primer.kunjunganketerangansehat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/yankes-primer/kunjunganketerangansehat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.yankes-primer.kunjunganketerangansehat',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/yankes-primer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/YankesPrimer/KunjunganKeteranganSehat',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.farmasi.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/farmasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.farmasi.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/farmasi',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Farmasi/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.farmasi.permintaanobat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/farmasi/permintaanobat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.farmasi.permintaanobat',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/farmasi',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Farmasi/PermintaanObat',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.biakes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/biakes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.biakes.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/biakes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Biakes/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.biakes.pembiayaanjaminansehat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/biakes/pembiayaanjaminansehat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\MalSehat\\BiakesController@pembiayaanJaminanSehat',
        'controller' => 'App\\Http\\Controllers\\MalSehat\\BiakesController@pembiayaanJaminanSehat',
        'as' => 'mal-sehat.biakes.pembiayaanjaminansehat',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/biakes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.biakes.pembiayaanjaminansehat.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/biakes/pembiayaanjaminansehat/pelayanan/{no_mr}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\MalSehat\\BiakesController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\MalSehat\\BiakesController@pelayanan',
        'as' => 'mal-sehat.biakes.pembiayaanjaminansehat.pelayanan',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/biakes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.promkes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/promkes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.promkes.index',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/promkes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Promkes/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.promkes.kesehatanpeduliremaja' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/promkes/kesehatanpeduliremaja',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@kesehatanPeduliRemaja',
        'controller' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@kesehatanPeduliRemaja',
        'as' => 'mal-sehat.promkes.kesehatanpeduliremaja',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/promkes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.promkes.kesehatanpeduliremaja.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/promkes/kesehatanpeduliremaja/pelayanan/{no_mr}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@pelayanan',
        'as' => 'mal-sehat.promkes.kesehatanpeduliremaja.pelayanan',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/promkes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.promkes.diagnosa.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/promkes/diagnosa/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@getDiagnosa',
        'controller' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@getDiagnosa',
        'as' => 'mal-sehat.promkes.diagnosa.list',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/promkes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.promkes.tindakan.list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/promkes/tindakan/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@getTindakan',
        'controller' => 'App\\Http\\Controllers\\MalSehat\\PromkesController@getTindakan',
        'as' => 'mal-sehat.promkes.tindakan.list',
        'namespace' => NULL,
        'prefix' => 'mal-sehat/promkes',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.home-visit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/home-visit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.home-visit',
        'namespace' => NULL,
        'prefix' => '/mal-sehat',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/HomeVisit/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.sehat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/sehat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.sehat',
        'namespace' => NULL,
        'prefix' => '/mal-sehat',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Sehat/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.sehat.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/sehat/pelayanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.sehat.pelayanan',
        'namespace' => NULL,
        'prefix' => '/mal-sehat',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/Sehat/Pelayanan',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'mal-sehat.rapid-test' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'mal-sehat/rapid-test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'as' => 'mal-sehat.rapid-test',
        'namespace' => NULL,
        'prefix' => '/mal-sehat',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'MalSehat/RapidTest/Index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/{idPoli?}/{klaster?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@index',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@index',
        'as' => 'kunj-online.index',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/pelayanan/{id}/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@pelayanan',
        'as' => 'kunj-online.pelayanan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.setAnamnesa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/pelayanan/anamnesa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@setAnamnesa',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@setAnamnesa',
        'as' => 'kunj-online.setAnamnesa',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.setAnamnesaObjective' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/pelayanan/anamnesa/objective',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@setAnamnesaObjective',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@setAnamnesaObjective',
        'as' => 'kunj-online.setAnamnesaObjective',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.mulai-pemeriksaan-pasien' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/pelayanan/mulaiPelayanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@mulaiPemeriksaanPasien',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@mulaiPemeriksaanPasien',
        'as' => 'kunj-online.mulai-pemeriksaan-pasien',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.diagnosa-medis' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/pelayanan/diagnosa-medis',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@setDiagnosaMedis',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@setDiagnosaMedis',
        'as' => 'kunj-online.diagnosa-medis',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.surat-rujukan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/surat-rujukan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@suratRujukan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@suratRujukan',
        'as' => 'kunj-online.surat-rujukan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.surat-rujukan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/{id}/surat-rujukan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@createSuratRujukan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@createSuratRujukan',
        'as' => 'kunj-online.surat-rujukan.create',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.surat-rujukan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/{id}/surat-rujukan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@storeSuratRujukan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@storeSuratRujukan',
        'as' => 'kunj-online.surat-rujukan.store',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.riwayat-kesehatan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/{id}/riwayat-kesehatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@riwayatKesehatan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@riwayatKesehatan',
        'as' => 'kunj-online.riwayat-kesehatan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kunj-online.cppt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/kunjungan-online/{id}/cppt',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@cppt',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KunjOnline\\KunjOnlineController@cppt',
        'as' => 'kunj-online.cppt',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan/simpus/kunjungan-online',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.poli' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/poli',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@listPoli',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@listPoli',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.poli',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.poli-kluster' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/poli/{kluster}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@listPoliKluster',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@listPoliKluster',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.poli-kluster',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/{idPoli?}/{kluster?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@index',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@index',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/{id}/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@pelayanan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.pelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.surat-rujuk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/surat-rujuk/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suratRujukList',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suratRujukList',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.surat-rujuk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.surat-rujuk-form' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/surat-rujuk-form/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suratRujukForm',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suratRujukForm',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.surat-rujuk-form',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpan-rujukan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/simpan-rujukan/{idPoli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSuratRujuk',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSuratRujuk',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpan-rujukan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.cetak-rujukan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/cetak-rujukan/{idSurat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@cetakRujukan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@cetakRujukan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.cetak-rujukan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.surat-rujuk-form-edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/surat-rujukan-form-edit/{idPoli}/{idPelayanan}/{idSurat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suratRujukForm',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suratRujukForm',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.surat-rujuk-form-edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.update-rujukan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/update-surat-rujukan/{idPoli}/{idSurat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSuratRujuk',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSuratRujuk',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.update-rujukan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.hapus-surat-rujukan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/hapus-surat-rujukan/{idSurat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusSuratRujukan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusSuratRujukan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.hapus-surat-rujukan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-umum.form-surat-keterangan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/umum/form-surat-keterangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-umum.form-surat-keterangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/Umum/form_surat_keterangan',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.setAnamnesaSubjective' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/set-anamnesa-subjective/{idLoket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setAnamnesaSubjective',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setAnamnesaSubjective',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.setAnamnesaSubjective',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.setAnamnesaObjective' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/umum/pelayanan/set-anamnesa-objective/{idAnam}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setAnamnesaObjective',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setAnamnesaObjective',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.setAnamnesaObjective',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpan-Tindakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/tindakan/{idPoli}/{idLoket}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setTindakan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setTindakan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpan-Tindakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.master-tindakan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/master-tindakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@paginasiSimpusTindakan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@paginasiSimpusTindakan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.master-tindakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-umum.mulai-pemeriksaan-pasien' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/umum/pelayanan/mulaiPelayanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@mulaiPemeriksaanPasien',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@mulaiPemeriksaanPasien',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-umum.mulai-pemeriksaan-pasien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.set-diagnosa-medis' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/diagnosa-medis/{idLoket}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setDiagnosaMedis',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setDiagnosaMedis',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.set-diagnosa-medis',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.diagnosa-keperawatan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/diagnosa/diagnosa-keperawatan-simpan/{idLoket}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setDiagnosaKeperawatan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setDiagnosaKeperawatan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.diagnosa-keperawatan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.diagnosa-medis' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/api/diagnosa-medis',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@paginasi',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@paginasi',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'api.diagnosa-medis',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.remove-diagnosa-medis' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/diagnosa-medis/{idDiagnosa}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@removeDiagnosaMedis',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@removeDiagnosaMedis',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.remove-diagnosa-medis',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.remove-diagnosa-keperawatan' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/diagnosa-keperawatan{idDiagnosa}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@removeDiagnosaKeperawatan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@removeDiagnosaKeperawatan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.remove-diagnosa-keperawatan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpan-gizi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/simpan-gizi/{idLoket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanGizi',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanGizi',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpan-gizi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpan-sanitasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/simpan-sanitasi/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSanitasi',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSanitasi',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpan-sanitasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.set-resep-obat' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/resep-obat/{idLoket}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setResepObat',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setResepObat',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.set-resep-obat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.set-detail-resep' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/detail-resep-obat/{idResep}/{idObat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setDetailResepObat',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@setDetailResepObat',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.set-detail-resep',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.hapus-resep-obat' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'ruang_layanan/simpus/hapus-resep-obat/{idResepObat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusResepObat',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusResepObat',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.hapus-resep-obat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.hapus-detail-resep-obat' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/hapus-detail-resep-obat/{idDetailResepObat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusDetailResepObat',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusDetailResepObat',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.hapus-detail-resep-obat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpanRujukan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/simpan-rujuk/{idLoket}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanRujukan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanRujukan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpanRujukan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.ambilPelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/get-pelayanan/{idLoket}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@getPelayanan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@getPelayanan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.ambilPelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.hapusRujuk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/hapus-rujuk/{idpelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusRujuk',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusRujuk',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.hapusRujuk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.batal-berobat-jalan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayanan/batal-berobat-jalan/{idLoket}/{idpelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@batalBerobatJalan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@batalBerobatJalan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.batal-berobat-jalan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.surat-keterangan-list' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/surat-keterangan-list/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suketList',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@suketList',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.surat-keterangan-list',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.create-surat-keterangan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/create-surat-keterangan/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@createSuratKeterangan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@createSuratKeterangan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.create-surat-keterangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpanSuket' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/simpan-surat-keterangan/{idPoli}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSuket',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanSuket',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpanSuket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.cetak-suket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/cetak-surat-keterangan/{idSurat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@cetakSuket',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@cetakSuket',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.cetak-suket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.hapus-suket' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/hapus-surat-keterangan/{idSurat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusSuket',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@hapusSuket',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.hapus-suket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.edit-suket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pelayananDetail/edit-surat-keterangan//{idPoli}/{idPelayanan}/{idSurat}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@editSuket',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@editSuket',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.edit-suket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.update-suket' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/update-surat-keterangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@updateSuket',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@updateSuket',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.update-suket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.form-laborat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/laborat/{idPoli}/{idLoket}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@formLaborat',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@formLaborat',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.form-laborat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpan-permohonan-lab' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/umum/laborat/simpan-permohonan-lab/{idLoket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanPermohonanLab',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanPermohonanLab',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpan-permohonan-lab',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.getPermonanLab' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/laborat/list-permohonan/{idLoket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@getPermohonanLaborat',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@getPermohonanLaborat',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.getPermonanLab',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.riwayat-pasien' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/riwayat-pasien/{idPoli}/{idPasien}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@riwayatPasien',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@riwayatPasien',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.riwayat-pasien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.get-ukk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/pop-up/get-ukk/{idLoket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@getUKK',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@getUKK',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.get-ukk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.simpan-ukk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/simpan-ukk/{idLoket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanUkk',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@simpanUkk',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.simpan-ukk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.cppt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/cppt/{idPoli}/{idPasien}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@getCppt',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliBpUmumController@getCppt',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.cppt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.gigi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/gigi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@index',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@index',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.gigi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@pelayanan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.pelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.setAnamnesaSubjective' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/anamnesa-subjective',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setAnamnesaSubjective',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setAnamnesaSubjective',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.setAnamnesaSubjective',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.setAnamnesaObjective' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/anamnesa-objective',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setAnamnesaObjective',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setAnamnesaObjective',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.setAnamnesaObjective',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.diagnosa-medis' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/diagnosa-medis',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setDiagnosaMedis',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setDiagnosaMedis',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.diagnosa-medis',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.remove-diagnosa-medis' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/diagnosa-medis/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@removeDiagnosaMedis',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@removeDiagnosaMedis',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.remove-diagnosa-medis',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.set-PlanningTindakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/planning-tindakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setPlanningTindakan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setPlanningTindakan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.set-PlanningTindakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.remove-data-tindakan' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/planning-tindakan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@removePlanningTindakan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@removePlanningTindakan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.remove-data-tindakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.set-PlanningPengobatan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/planning-pengobatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setPlanningPengobatan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setPlanningPengobatan',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.set-PlanningPengobatan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-gigi.set-PlanningPengobatanDetail' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang_layanan/simpus/gigi/pelayanan/planning-pengobatan-detail',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setPlanningPengobatandetail',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliGigiController@setPlanningPengobatandetail',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-gigi.set-PlanningPengobatanDetail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.master-obat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/master-obat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@MasterObat',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\indexController@MasterObat',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.master-obat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.ranap' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/ranap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.ranap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/UGD/pasien_poli',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.sanitasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/sanitasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.sanitasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/Sanitasi/pasien_poli',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.sanitasi.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/sanitasi/pelayanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.sanitasi.pelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/Sanitasi/pelayanan',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.gizi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/gizi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.gizi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/Gizi/pasien_poli',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.gizi.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/gizi/pelayanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.gizi.pelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/Gizi/pelayanan',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.rawat-inap' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/rawat-inap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.rawat-inap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/RawatInap/index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.rawat-inap.penerimaan-pasien' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/rawat-inap/penerimaan-pasien',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.rawat-inap.penerimaan-pasien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/RawatInap/PenerimaanPasien/pasien_poli',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.rawat-inap.perawatan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/rawat-inap/perawatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.rawat-inap.perawatan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/RawatInap/DataKeperawatan/DataRanapKeperawatan',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.rawat-inap.pengeluaran' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/simpus/rawat-inap/pengeluaran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '/ruang_layanan',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.rawat-inap.pengeluaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/RawatInap/PasienKeluar/DataPasienKeluar',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/laborat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@index',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.pemeriksaan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/laborat/pemeriksaan/{loketId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@pemeriksaan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@pemeriksaan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.pemeriksaan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.setWaktuSample' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/set-waktu-sample',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@setWaktuSample',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@setWaktuSample',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.setWaktuSample',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.updateNilaiLab' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/update-nilai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@updateNilaiLab',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@updateNilaiLab',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.updateNilaiLab',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.paginasiMasterPemeriksaan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/laborat/paginasi-master-pemeriksaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paginasiMasterPemeriksaan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paginasiMasterPemeriksaan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.paginasiMasterPemeriksaan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.simpanPermohonan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/permohonan/simpan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@simpanPermohonan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@simpanPermohonan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.simpanPermohonan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.pemeriksaanSimpan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/pemeriksaan/simpan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@pemeriksaanSimpan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@pemeriksaanSimpan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.pemeriksaanSimpan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.paketPemeriksaanSimpan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/pemeriksaan/paket/{paket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:laborat',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paketPemeriksaanSimpan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paketPemeriksaanSimpan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.paketPemeriksaanSimpan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/laborat/detail/{idPermohonan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@detail',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@detail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.detail',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.param.headers' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/laborat/param/headers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramHeaders',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramHeaders',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.param.headers',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.param.subheaders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/laborat/param/{header}/subheaders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramSubheaders',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramSubheaders',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.param.subheaders',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'header' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.param.simpan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/param/{header}/simpan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramSimpan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramSimpan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.param.simpan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'header' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.hapusTindakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/tindakan/hapus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@hapusTindakan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@hapusTindakan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.hapusTindakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.param.browse' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/laborat/param/browse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramBrowse',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramBrowse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.param.browse',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.param.simpanTerpilih' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/laborat/param/simpan-terpilih',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramSimpanTerpilih',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramSimpanTerpilih',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.param.simpanTerpilih',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.kia' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/kia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Inertia\\Controller@__invoke',
        'controller' => '\\Inertia\\Controller',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.kia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'component' => 'Ruang_Layanan/KIA/index',
        'props' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.anc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/kia/anc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@index',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.anc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-anc.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/kia/anc/pelayanan/{id}/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@pelayanan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-anc.pelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-anc.kunjunganANC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/kia/anc/pelayanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setKunjunganANC',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setKunjunganANC',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-anc.kunjunganANC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-anc.obstetri' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/kia/anc/pelayanan/obstetri',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setObstetri',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setObstetri',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-anc.obstetri',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-anc.dataDiagnosa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/kia/anc/pelayanan/DataDiagnosa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setDataDiagnosa',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setDataDiagnosa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-anc.dataDiagnosa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'diagnosa.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'simpus/kia/anc/pelayanan/DataDiagnosa/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@hapusDataDiagnosa',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@hapusDataDiagnosa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'diagnosa.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-anc.diagnosaKep' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'simpus/kia/anc/pelayanan/diagnosaKep',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setDataDiagnosaKep',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\AncController@setDataDiagnosaKep',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-anc.diagnosaKep',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-kia.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/kia/pelayanan/{id}/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliKIAController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliKIAController@pelayanan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-kia.pelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.cari-diagnosa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/kia/cari-diagnosa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\PoliKIAController@searchDiagnosa',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\PoliKIAController@searchDiagnosa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'api.cari-diagnosa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.kematian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/kia/kematian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KematianController@index',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KematianController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.kematian',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan-kematian.pelayanan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'simpus/kia/kematian/pelayanan/{id}/{idPoli}/{idPelayanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\KematianController@pelayanan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\KematianController@pelayanan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan-kematian.pelayanan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.param.categories' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ruang_layanan/laborat/param/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramCategories',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@paramCategories',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.param.categories',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ruang-layanan.laborat.hapusSemuaTindakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ruang-layanan/laborat/hapus-semua',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@hapusSemuaTindakan',
        'controller' => 'App\\Http\\Controllers\\RuangLayanan\\LaboratoriumController@hapusSemuaTindakan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'ruang-layanan.laborat.hapusSemuaTindakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'owner.panel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'owner',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\PanelController@index',
        'controller' => 'App\\Http\\Controllers\\Owner\\PanelController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'owner.panel',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::929SgLF6K1sSbA1l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/owner/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@roles',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@roles',
        'namespace' => NULL,
        'prefix' => '/api/owner',
        'where' => 
        array (
        ),
        'as' => 'generated::929SgLF6K1sSbA1l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xEUl3DGQzzlEx2tU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/owner/puskesmas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@puskesmas',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@puskesmas',
        'namespace' => NULL,
        'prefix' => '/api/owner',
        'where' => 
        array (
        ),
        'as' => 'generated::xEUl3DGQzzlEx2tU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TkXbcLAg9C9weeGX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/owner/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@users',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@users',
        'namespace' => NULL,
        'prefix' => '/api/owner',
        'where' => 
        array (
        ),
        'as' => 'generated::TkXbcLAg9C9weeGX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0Tu3kCll1hTjSkX6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/owner/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@storeUser',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@storeUser',
        'namespace' => NULL,
        'prefix' => '/api/owner',
        'where' => 
        array (
        ),
        'as' => 'generated::0Tu3kCll1hTjSkX6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AwT5zG6wLB80VnNs' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/owner/users/{id}/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@updateRoles',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@updateRoles',
        'namespace' => NULL,
        'prefix' => '/api/owner',
        'where' => 
        array (
        ),
        'as' => 'generated::AwT5zG6wLB80VnNs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cyeFLlnkL92ikF14' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/owner/users/{id}/force-logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@forceLogout',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@forceLogout',
        'namespace' => NULL,
        'prefix' => '/api/owner',
        'where' => 
        array (
        ),
        'as' => 'generated::cyeFLlnkL92ikF14',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dWEsmJNoMt3zRdjl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/owner/online-users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@onlineUsers',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@onlineUsers',
        'namespace' => NULL,
        'prefix' => '/api/owner',
        'where' => 
        array (
        ),
        'as' => 'generated::dWEsmJNoMt3zRdjl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'auth.password.force-update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'auth/password/force-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\PasswordForceController@update',
        'controller' => 'App\\Http\\Controllers\\Auth\\PasswordForceController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'auth.password.force-update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'owner.loket-delete-logs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'owner/loket-delete-logs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
          3 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerLogController@loketDeletes',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerLogController@loketDeletes',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'owner.loket-delete-logs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'owner.logs.loket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'owner/logs/loket-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:93:"function () {
            return \\Inertia\\Inertia::render(\'Owner/LoketDeleteLogs\');
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007f50000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'owner.logs.loket',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'owner.users.password_changed' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'users/{id}/password-changed',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'App\\Http\\Middleware\\Auth\\CheckRole:owner',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@updatePasswordChanged',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@updatePasswordChanged',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'owner.users.password_changed',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'owner.users.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'users/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Owner\\OwnerController@destroyUser',
        'controller' => 'App\\Http\\Controllers\\Owner\\OwnerController@destroyUser',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'owner.users.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xwVWtC83jot7xld8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cek-db',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:96:"function () {
    $tables = \\DB::select(\'SHOW TABLES\');
    return \\response()->json($tables);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007f30000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xwVWtC83jot7xld8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:141:"C:\\Users\\akusu\\OneDrive\\Documents\\6. Magang MKI DINKES\\BACKUP\\newsimpuswangi-main\\newsimpuswangi-main\\newsimpuswangi-main\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000007f90000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
