<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class Kelurahan extends Model
{
    protected $table = 'setup_kel';
    //
}
