<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class MasterPekerjaan extends Model
{
    protected $table = 'pkrjn_master';
    //
}
