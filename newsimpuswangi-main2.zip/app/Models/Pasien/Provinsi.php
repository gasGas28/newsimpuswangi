<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class Provinsi extends Model
{
    protected $table = 'setup_prop';

    //
}
