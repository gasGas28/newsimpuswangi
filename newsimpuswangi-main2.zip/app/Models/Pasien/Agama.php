<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class Agama extends Model
{
    protected $table = 'agama_master';
    //
}
