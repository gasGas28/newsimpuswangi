<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="icon" type="image/webp" href="<?php echo e(asset('images/puskesmas2.webp')); ?>">

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

  <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
        integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer" />

  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
  <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
  <script>
    if (typeof Ziggy !== 'undefined') {
      Ziggy.absolute = false; // ← penting: bikin route() output relatif
    }
  </script>

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>

  <!-- Script reCAPTCHA (aman, HTTPS) -->
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</body>
</html>
<?php /**PATH C:\Users\Administrator\Documents\simpuswangi\resources\views/app.blade.php ENDPATH**/ ?>