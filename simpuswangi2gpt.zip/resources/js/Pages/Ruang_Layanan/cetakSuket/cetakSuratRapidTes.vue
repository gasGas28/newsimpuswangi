<!-- resources/js/Pages/Ruang_Layanan/cetakSuket/cetakSuratRapidTes.vue -->
<template>
  <div class="p-4">
    <h1 class="text-lg fw-bold mb-2">Cetak Surat Rapid Tes</h1>
    <p>Halaman ini belum selesai. Silakan kembali nanti.</p>
  </div>
</template>

<script setup>
// placeholder agar build sukses; isi logika nanti
</script>

<style scoped>
/* opsional */
</style>
