<?php

namespace App\Models\Filter;

use Illuminate\Database\Eloquent\Model;

class SimpusProvider extends Model
{
    protected $table = 'simpus_provider';  
}
