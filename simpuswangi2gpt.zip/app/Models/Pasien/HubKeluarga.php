<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class HubKeluarga extends Model
{
    protected $table = 'm_keluarga';
    // protected $primaryKey = 'KODE';
    // public $incrementing = false;
    // protected $keyType = 'string';
    //
}
