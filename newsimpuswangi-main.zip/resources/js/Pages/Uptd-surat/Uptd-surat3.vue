<template>
  <AppLayout>
    <div class="container py-4">
      <!-- Laporan -->
      <div
        class="lab-report p-4 mb-5 bg-white border rounded shadow"
        style="max-width: 840px; margin: auto; font-size: 15px; position: relative"
      >
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-2">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/f/f5/Lambang_Kabupaten_Banyuwangi.png"
            alt="Banyuwangi"
            height="60"
            style="margin-right: 8px"
          />
          <div class="w-100 text-center">
            <div class="fw-bold text-uppercase" style="font-size: 17px">
              PEMERINTAH KABUPATEN BANYUWANGI
            </div>
            <div class="fw-bold" style="font-size: 16px">DINAS KESEHATAN</div>
            <div class="fw-bold" style="font-size: 15px">UPTD LABORATORIUM KESEHATAN DAERAH</div>
            <div class="fw-bold" style="font-size: 13px">
              Jl. Letkol Istiqlah No.40 Banyuwangi Telepon (0333) 429444
            </div>
            <div style="font-size: 13px">Email: labkesdabanyuwangi@gmail.com</div>
          </div>
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/d/de/Logo_of_the_Ministry_of_Health_of_the_Republic_of_Indonesia.png"
            alt="Kemenkes"
            height="60"
            style="margin-left: 8px"
          />
        </div>

        <hr class="my-2" />
        <!-- Dua Kolom: Info Surat dan Tujuan -->
        <div class="row small mt-3">
          <table class="table table-sm">
            <tbody>
              <tr>
                <td></td>
                <td></td>
                <td colspan="4" class="text-center fw-bold">Banyuwangi, 24 Mei 2025</td>
                <td></td>
              </tr>
              <tr>
                <td>Nomor</td>
                <td>:</td>
                <td>440/654/429.112.46/2025</td>
                <td rowspan="5">
                  <p class="fw-semibold mb-1">Kepada Yth.</p>
                  <p class="mb-1">Manajemen CV. Permata Bogania Nusantara</p>
                  <p class="mb-1">Perum Mendut Regency Blok I-5</p>
                  <p class="mb-1">Kelurahan Mojopanggung, Kec. Giri</p>
                  <p class="mb-0">Kabupaten Banyuwangi</p>
                </td>
              </tr>
              <tr>
                <td>Lampiran</td>
                <td>:</td>
                <td>-</td>
              </tr>
              <tr>
                <td>Perihal</td>
                <td>:</td>
                <td>LAPORAN HASIL ANALISA LABORATORIUM</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="mt-3">
          <p>Disampaikan dengan hormat hasil pemeriksaan Laboratorium kami, sebagai berikut :</p>
        </div>
        <table class="table table-sm">
          <tbody>
            <tr>
              <th class="w-25">Sampel diterima Tanggal</th>
              <td>: 17 Mei 2025</td>
            </tr>
            <tr>
              <th>Nama Pengambil</th>
              <td>: Martono, ST & Nilam YS</td>
            </tr>
            <tr>
              <th>Instansi Pengambil Sampel</th>
              <td>: Dinas Kesehatan Banyuwangi</td>
            </tr>
            <tr>
              <th>Asal Sampel</th>
              <td>: CV. Permata Boganita Nusantara</td>
            </tr>
            <tr>
              <th>Alamat Pengambilan Sampel</th>
              <td>
                : Manajemen CV. Permata Bogania Nusantara<br />
                Perum Mendut Regency Blok I-5<br />
                Kelurahan Mojopanggung, Kecamatan Giri
              </td>
            </tr>
            <tr>
              <th>No. Register</th>
              <td>: 46.2473.16.654</td>
            </tr>
          </tbody>
        </table>

        <table class="table table-bordered border-black table-sm">
          <thead class="table-light">
            <tr>
              <th>No</th>
              <th>Jenis Bahan Uji</th>
              <th>Identifikasi</th>
              <th>Hasil Kultur</th>
              <th>Satuan</th>
              <th>Nilai Rujukan</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="5">1</td>
              <td rowspan="5">Ayam Saos Tiram</td>
              <td>Angka Lempeng Total</td>
              <td class="text-center">0</td>
              <td class="text-center">Koloni/g</td>
              <td class="text-center">10⁵ Koloni/g</td>
            </tr>
            <tr>
              <td><em>Salmonella Sp</em></td>
              <td class="text-center">Negatif</td>
              <td class="text-center">-</td>
              <td class="text-center">Negatif</td>
            </tr>
            <tr>
              <td><em>E. Coli</em></td>
              <td class="text-center">Negatif</td>
              <td class="text-center">-</td>
              <td class="text-center">Negatif</td>
            </tr>
            <tr>
              <td><em>Staphylococcus aureus</em></td>
              <td class="text-center">Negatif</td>
              <td class="text-center">-</td>
              <td class="text-center">Negatif</td>
            </tr>
            <tr>
              <td><em>Vibrio cholerae</em></td>
              <td class="text-center">Negatif</td>
              <td class="text-center">-</td>
              <td class="text-center">Negatif</td>
            </tr>
            <tr>
              <td colspan="6">
                <h6 class="fw-bold ps-2">Catatan :</h6>
              </td>
            </tr>
            <tr>
              <td colspan="6" class="small">
                <h6 class="text-decoration-underline fw-bold ps-2">REKOMENDASI</h6>
                <ul class="mt-2">
                  <li>
                    Terima kasih atas peran aktifnya dalam pengawasan kualitas makanan di lingkungan
                    restoran yang saudara kelola.
                  </li>
                  <li>
                    Hasil analisa menunjukkan TIDAK MENGANDUNG bakteri
                    <em>Salmonella sp</em>, <em>E. coli</em>, <em>Staphylococcus aureus</em>,
                    <em>Vibrio cholerae</em>.
                  </li>
                  <li>Inspeksi sanitasi dan kebersihan tetap dilakukan secara berkala.</li>
                  <li>Pemeriksaan minimal setiap 6 bulan atau sesuai ketentuan.</li>
                </ul>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="small">
          <p>
            Batas syarat berdasarkan:
            <em>BPOM RI No 16 Tahun 2016</em><br />
            Demikian hasil analisa laboratorium kami, untuk dapat dipergunakan sebelumnya.
          </p>
        </div>

        <div class="row small mt-2">
          <!-- PERHATIAN Box -->
          <div class="col-md-6">
            <div class="border border-black border-1 p-3 rounded" style="font-size: 13px">
              <strong>PERHATIAN :</strong><br />
              Hasil pengujian ini hanya berlaku pada contoh di atas<br />
              Lembar ini
              <strong>TIDAK UNTUK DIPUBLIKASIKAN</strong><br />
              Lembar ini <strong>BUKAN SERTIFIKASI</strong>
            </div>
          </div>

          <!-- Tanda Tangan -->
          <div class="col-md-6 text-end">
            <p class="mb-1">KEPALA UPTD LABKESDA</p>
            <p class="mb-1">DINAS KESEHATAN KAB. BANYUWANGI</p>
            <div style="height: 56px"></div>
            <p class="mb-1 fw-bold">KUSRIONO, S.Si</p>
            <p class="mb-0">NIP. 19751222 199703 1 004</p>
          </div>
        </div>

        <!-- Tembusan -->
        <div class="small mt-4">
          <strong>Tembusan Yth:</strong>
          <ol class="mt-2 ps-3">
            <li>
              Sub Koordinator Kesehatan Lingkungan Kesehatan Kerja & Olahraga
              <div>Dinas Kesehatan Kab. Banyuwangi</div>
            </li>
            <li>Arsip</li>
          </ol>
        </div>
      </div>
    </div>
  </AppLayout>
</template>
<script setup>
  import AppLayout from '@/Components/Layouts/AppLayouts.vue';
</script>
