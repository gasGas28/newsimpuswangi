<?php

namespace App\Models\Filter;

use Illuminate\Database\Eloquent\Model;

class DiagnosaKasus extends Model
{
    protected $table = 'master_diagnosa_kasus';
    //
}
