<?php

namespace App\Models\Filter;

use Illuminate\Database\Eloquent\Model;

class UnitFilter extends Model
{
    protected $table = 'simpus_poli_fktp';
    //
}
