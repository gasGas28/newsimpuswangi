<?php

namespace App\Models\RuangLayanan;

use Illuminate\Database\Eloquent\Model;

class masterJenisUkk extends Model
{
    protected $table = 'master_jenis_ukk';
    public $timestamps = false;
    protected $primaryKey = 'id_jenis';

}
