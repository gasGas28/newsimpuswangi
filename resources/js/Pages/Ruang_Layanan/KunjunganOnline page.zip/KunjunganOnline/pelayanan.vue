<template>
  <AppLayouts>
    <div class="card m-4 rounded-4 rounded-bottom-0">
      <div
        class="card-header bg-info d-flex justify-content-between p-3 rounded-4 rounded-bottom-0"
        style="background: linear-gradient(135deg, #3b82f6, #10b981);"
      >
        <h1 class="fs-5 text-white">Kunjungan Online</h1>
        <Link :href="backRoute" class="btn bg-white bg-opacity-25 border border-1 btn-sm text-white">
          <i class="fas fa-arrow-left me-1 text-white"></i> Kembali
        </Link>
      </div>

      <div class="card-body">
        <!-- sesuai reusable: dataPasien = Array, dataAnamnesa = Array -->
        <PelayananPasien
          :dataPasien="DataPasienArr"
          :dataAnamnesa="DataAnamnesaArr"
          @ubah-melayani="isMelayani = $event"
        >
          <div class="shadow-sm rounded-5">
            <NavigasiFormPemeriksaan
              :currentTab="currentTab"
              @change-currentTab="currentTab = $event"
            />
            <div class="m-4 pb-4 row gx-5">
              <FormPelayananSubjective
                v-if="currentTab === 'subjective'"
                :idLoket="DataPasienArr[0]?.idLoket || ''"
                :dataAnamnesa="DataAnamnesaArr"
                :masterAlergi="MasterAlergiArr"
              />
              <FormPelayananObjective
                v-if="currentTab === 'objective'"
                :currentSub="true"
                halaman="umum"
                :dataKesadaran="DataKesadaranArr"
                :dataAnamnesa="DataAnamnesaArr"
              />
              <FormPelayananAssesment
                v-if="currentTab === 'assesment'"
                :diagnosaKasus="DiagnosaKasusArr"
                :dataPasien="DataPasienObj"
              />
              <FormPelayananPlanning v-if="currentTab === 'planning'" />
              <FormPelayananStatusPasien v-if="currentTab === 'status_pasien'" />
            </div>
          </div>
        </PelayananPasien>
      </div>
    </div>
  </AppLayouts>
</template>

<script setup>
import AppLayouts from '../../../Components/Layouts/AppLayouts.vue'
import PelayananPasien from '../../../Components/Layouts/RuangLayanan/KunjOnline/PelayananPasien.vue'
import FormPelayananSubjective from '../../../Components/Layouts/RuangLayanan/KunjOnline/PelayananPasien/FormPelayananSubjective.vue'
import FormPelayananObjective from '../../../Components/Layouts/RuangLayanan/KunjOnline/PelayananPasien/FormPelayananObjective.vue'
import FormPelayananAssesment from '../../../Components/Layouts/RuangLayanan/KunjOnline/PelayananPasien/FormPelayananAssesment.vue'
import FormPelayananPlanning from '../../../Components/Layouts/RuangLayanan/KunjOnline/PelayananPasien/FormPelayananPlanning.vue'
import FormPelayananStatusPasien from '../../../Components/Layouts/RuangLayanan/KunjOnline/PelayananPasien/FormPelayananStatusPasien.vue'
import NavigasiFormPemeriksaan from '../../../Components/Layouts/RuangLayanan/KunjOnline/PelayananPasien/NavigasiFormPemeriksaan.vue'

import { ref, computed } from 'vue'
import { Link, usePage } from '@inertiajs/vue3'
import { route } from 'ziggy-js'

const isMelayani = ref(false)
const currentTab = ref('subjective')

// Ambil props dari Inertia
const { props } = usePage()

// --- DataPasien: sediakan Object & Array (reusable minta Array)
const RawPasien = computed(() => {
  if (Array.isArray(props.DataPasien)) return props.DataPasien[0] ?? null
  return props.DataPasien ?? null
})

const DataPasienArr = computed(() => {
  return RawPasien.value
    ? [RawPasien.value]
    : [{ idLoket: '', NO_MR: '-', NAMA_LGKP: '-' }]
})

const DataPasienObj = computed(() => RawPasien.value ?? { idLoket: '', NO_MR: '-', NAMA_LGKP: '-' })

// --- DataAnamnesa: SELALU Array & punya struktur subjective.alergi
const DataAnamnesaArr = computed(() => {
  const src = props.DataAnamnesa
  if (Array.isArray(src) && src.length) return src
  // sentinel mengikuti akses child: dataAnamnesa[0].subjective.alergi[0]
  return [{
    subjective: {
      alergi: []         // <- penting: ada array ini, jadi akses [0] aman (undefined tanpa crash)
    },
    keluhan_utama: '',
    riwayat_penyakit: ''
  }]
})

// --- MasterAlergi: selalu Array & minimal 1 item (kalau child butuh [0].kode, tetap aman)
const MasterAlergiArr = computed(() => {
  const src = props.MasterAlergi
  if (Array.isArray(src) && src.length) return src
  return [{ kode: '', nama: '' }]
})

// --- Lain-lain
const DataKesadaranArr = computed(() => Array.isArray(props.DataKesadaran) ? props.DataKesadaran : [])
const DiagnosaKasusArr = computed(() => Array.isArray(props.DiagnosaKasus) ? props.DiagnosaKasus : [])
const DiagnosaMedisArr = computed(() => Array.isArray(props.DiagnosaMedis) ? props.DiagnosaMedis : [])

// Tombol kembali
const backRoute = route('ruang-layanan.kunjungan-online')
</script>

<style>
.tab-item{border:none;background:transparent;font-weight:500;border-radius:0;position:relative;transition:all .3s ease;color:#6c757d}
.tab-item:hover{color:#495057!important}
.tab-item.active{color:#0d6efd!important;font-weight:600}
.tab-indicator{position:absolute;bottom:-16px;left:0;height:3px;background-color:#0d6efd;transition:all .3s ease;z-index:1;border-radius:3px 3px 0 0}
</style>
