<template>
  <div class="card p-3 rounded-4">
    <h5 class="mb-3">Subjective</h5>

    <div class="mb-3 small text-muted">
      <span class="me-2">ID Loket:</span><strong>{{ idLoket || '-' }}</strong>
    </div>

    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Keluhan Utama</label>
        <input
          type="text"
          class="form-control"
          v-model="form.keluhan_utama"
          placeholder="Masukkan keluhan utama"
        />
      </div>

      <div class="col-md-6">
        <label class="form-label">Riwayat Penyakit</label>
        <input
          type="text"
          class="form-control"
          v-model="form.riwayat_penyakit"
          placeholder="Masukkan riwayat penyakit"
        />
      </div>

      <!-- Alergi: pakai SELECT kalau ada opsi (subjective.alergi atau masterAlergi); selain itu TEXT -->
      <div class="col-md-6">
        <label class="form-label">Alergi</label>

        <template v-if="useSelectAllergy">
          <select class="form-select" v-model="form.alergi_kode">
            <option value="">- Pilih alergi -</option>
            <option
              v-for="(al, i) in allergyOptions"
              :key="i"
              :value="al.kode ?? ''"
            >
              {{ al.nama ?? ('Alergi ' + (i + 1)) }}
            </option>
          </select>
          <div class="form-text">Sumber: opsi dari <code>subjective.alergi</code> atau <code>masterAlergi</code>.</div>
        </template>

        <template v-else>
          <input
            type="text"
            class="form-control"
            v-model="form.alergi_text"
            placeholder="Tulis alergi pasien (jika ada)"
          />
          <div class="form-text">Sumber: field <code>alergi</code> (top-level) pada data.</div>
        </template>
      </div>
    </div>

    <!-- Debug -->
    <details class="mt-3">
      <summary>Debug data (sementara)</summary>
      <pre class="mt-2 small">{{ firstAnamnesa }}</pre>
      <pre class="mt-2 small">useSelectAllergy: {{ useSelectAllergy }}</pre>
    </details>
  </div>
</template>

<script setup>
import { computed, reactive, watchEffect } from 'vue'

const props = defineProps({
  idLoket: { type: [String, Number], default: '' },
  dataAnamnesa: { type: Array, default: () => [] },
  masterAlergi: { type: Array, default: () => [] },
})

const firstAnamnesa = computed(() =>
  Array.isArray(props.dataAnamnesa) && props.dataAnamnesa.length
    ? props.dataAnamnesa[0]
    : {}
)

// Ambil opsi alergi dari subjective.alergi (array) kalau ada; kalau tidak, pakai masterAlergi
const allergyOptions = computed(() => {
  const subArr = firstAnamnesa.value?.subjective?.alergi
  if (Array.isArray(subArr) && subArr.length) return subArr
  if (Array.isArray(props.masterAlergi) && props.masterAlergi.length) return props.masterAlergi
  return []
})

const useSelectAllergy = computed(() => allergyOptions.value.length > 0)

const form = reactive({
  keluhan_utama: '',
  riwayat_penyakit: '',
  alergi_kode: '', // untuk SELECT mode
  alergi_text: '', // untuk TEXT mode
})

watchEffect(() => {
  const a = firstAnamnesa.value

  // Mapping fleksibel sesuai data kamu
  form.keluhan_utama =
    a?.keluhan ??
    a?.keluhan_utama ??
    ''

  form.riwayat_penyakit =
    a?.riwayatPenyakitSekarang ??
    a?.riwayatPenyakitDahulu ??
    a?.riwayat_penyakit ??
    ''

  if (useSelectAllergy.value) {
    const first = allergyOptions.value[0]
    form.alergi_kode = first?.kode ?? ''
    form.alergi_text = ''
  } else {
    // top-level 'alergi' (string/null) → jadikan text
    form.alergi_text = typeof a?.alergi === 'string' ? a.alergi : ''
    form.alergi_kode = ''
  }
})
</script>

<style scoped>
pre { white-space: pre-wrap; word-break: break-word; }
</style>
