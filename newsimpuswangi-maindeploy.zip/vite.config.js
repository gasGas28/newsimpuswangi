// vite.config.js
import { defineConfig } from 'vite'
import laravel from 'laravel-vite-plugin'
import vue from '@vitejs/plugin-vue'
import ziggy from 'vite-plugin-ziggy'
import path from 'path'

export default defineConfig({
  plugins: [
    vue(),
    laravel({
      input: ['resources/css/app.css', 'resources/js/app.js'],
      refresh: true,
    }),
    ziggy(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './resources/js'),
      // ❌ HAPUS baris alias 'vue' yang lama
      // vue: path.resolve(__dirname, 'node_modules/vue'),
    },
    // ✅ biarkan dedupe untuk memastikan cuma 1 runtime Vue yang dipakai
    dedupe: ['vue', '@vue/runtime-core', '@vue/runtime-dom'],
  },
  // ❌ HAPUS blok optimizeDeps yang memaksa prebundle 'vue'
  // optimizeDeps: {
  //   include: ['vue', '@inertiajs/vue3'],
  //   force: true,
  // },
  server: {
    host: true,
    port: 5173,
    strictPort: true,
    hmr: {
      host: 'dev-hmr.safiradmin.com',
      protocol: 'wss',
      clientPort: 443,
    },
  },
})
