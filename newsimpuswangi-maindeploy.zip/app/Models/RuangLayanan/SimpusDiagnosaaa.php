<?php

namespace App\Models\RuangLayanan;

use Illuminate\Database\Eloquent\Model;

class SimpusDiagnosaaa extends Model
{
    protected $table = 'simpus_diagnosaaa';
    //
}
