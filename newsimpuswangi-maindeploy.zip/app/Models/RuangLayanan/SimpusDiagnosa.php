<?php

namespace App\Models\RuangLayanan;

use Illuminate\Database\Eloquent\Model;

class SimpusDiagnosa extends Model
{
    protected $table = 'simpus_diagnosa';
    protected $primaryKey = 'id';
}
