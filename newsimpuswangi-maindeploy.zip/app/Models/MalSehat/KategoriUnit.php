<?php

namespace App\Models\MalSehat;

use Illuminate\Database\Eloquent\Model;

class KategoriUnit extends Model
{
    protected $table = 'data_master_unit_detail';
    //
}
