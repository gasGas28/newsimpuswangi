<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class Kecamatan extends Model
{
    protected $table = 'setup_kec';
    //
}
