<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class Kabupaten extends Model
{
    protected $table = 'setup_kab';
    //
}
