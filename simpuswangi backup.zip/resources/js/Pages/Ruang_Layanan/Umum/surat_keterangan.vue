<template>
    <AppLayouts>
        <SuratKeterangan>
            
        </SuratKeterangan>
    </AppLayouts>
</template>
<script setup>
import SuratKeterangan from '../../../Components/Layouts/RuangLayanan/PelayananPasien/SuratKeterangan.vue';
import AppLayouts from '../../../Components/Layouts/AppLayouts.vue';
</script>