<template>
    <AppLayouts>
        <FormSuratKeterangan>
            
        </FormSuratKeterangan>
    </AppLayouts>

</template>

<script setup>
import FormSuratKeterangan from '../../../Components/Layouts/RuangLayanan/PelayananPasien/FormSuratKeterangan.vue';
import AppLayouts from '../../../Components/Layouts/AppLayouts.vue';
</script>