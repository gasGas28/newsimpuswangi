<?php

namespace App\Models\Pasien;

use Illuminate\Database\Eloquent\Model;

class Pasien extends Model
{
    protected $table = 'simpus_pasien';
}
