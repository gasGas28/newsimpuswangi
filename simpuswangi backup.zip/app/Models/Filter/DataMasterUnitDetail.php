<?php

namespace App\Models\Filter;

use Illuminate\Database\Eloquent\Model;

class DataMasterUnitDetail extends Model
{
    protected $table = "data_master_unit_detail";
    //
}
