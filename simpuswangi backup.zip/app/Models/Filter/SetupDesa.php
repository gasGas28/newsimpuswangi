<?php

namespace App\Models\Filter;

use Illuminate\Database\Eloquent\Model;

class SetupDesa extends Model
{
    protected $table = 'setup_kel';
    //
}
