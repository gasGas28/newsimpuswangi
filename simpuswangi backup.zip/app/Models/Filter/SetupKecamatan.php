<?php

namespace App\Models\Filter;

use Illuminate\Database\Eloquent\Model;

class SetupKecamatan extends Model
{
    protected $table = 'setup_kec';
}
